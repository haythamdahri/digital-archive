Calculator Tutorial
===================

This sample project is a result of completing tutorial
that can be found at http://www.jetbrains.com/mps/docs/tutorial.html.

We've also added an ability to execute your calculators using 
context menu on calculator node in samples model. For the calculator
to be executable, files should be generated from it. 
Plugin language was used to implement this feature (see calculator 
language's plugin aspect). This language is not a basic MPS language
and therefore it wasn't described in tutorial.
